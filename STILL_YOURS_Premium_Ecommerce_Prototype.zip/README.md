# STILL YOURS — Premium E-commerce Prototype

A dependency-light, responsive frontend prototype for the STILL YOURS fashion-tech concept.

## Run
Open `index.html` directly in a browser, or serve the folder with any static server.

## Included prototype flows
- Sticky responsive navigation + smooth anchors
- Shop category filters and live search
- Product detail modal
- Add to bag, quantity controls, wishlist with localStorage
- AI Style Match: image upload/drag-drop → analysis loading states → mock recommendations
- AI Customization: image upload → live design preview → simulated generation
- Product mockups: tee / hoodie / tote
- QR Memory technology demonstration
- Memory Wall stories + submission flow
- Contact and newsletter forms
- Responsive mobile navigation
- Empty/loading/error states
- Roadmap labels distinguish live prototype behaviour from coming-soon technology

## Production AI integration
The AI Style Match prototype is intentionally mock-powered. Replace `showAIResult()` / `runAI()` in `app.js` with a secure backend endpoint that sends the uploaded image to your chosen vision model. Do not put provider API keys in browser JavaScript.

## Brand source
The visual and product-story direction is based on the supplied pitch deck: garment → story → AI match → new form → QR memory, with trust, personalization and a second-story positioning.
